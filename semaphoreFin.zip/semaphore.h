#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>
class Semaphore
{
public:



	Semaphore(int m) : maxThreads(m),  cv(),  mutex() {}

	int getMaxThreads() const { return maxThreads; }


	void wait();
	void signal();
private:

	
	int maxThreads;
	std::condition_variable cv;
	std::mutex mutex;
};
