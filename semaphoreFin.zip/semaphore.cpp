#include "semaphore.h"

void Semaphore::wait()
{
	std::unique_lock<std::mutex> lock(mutex);
	while (!maxThreads)
	{
		cv.wait(lock);
	}

	--maxThreads;

	return;
}

void Semaphore::signal()
{
	std::unique_lock<std::mutex> lock(mutex);
	++maxThreads;
	lock.unlock();
	cv.notify_all();
	return;
}